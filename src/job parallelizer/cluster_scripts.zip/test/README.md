# Cluster MWE scripts

First, install conda:
```
ssh <username>@master.ismll.de
wget https://repo.continuum.io/miniconda/Miniconda3-latest-Linux-x86_64.sh
bash Miniconda3-latest-Linux-x86_64.sh
```
Follow the installation instructions, after that **log off and on again**.

Secondly, set up virtual environments for the `CPU` and `GPU` nodes:
```bash
conda create --name GPU tensorflow-gpu
conda create --name CPU tensorflow-mkl
```
These environments can now be activated via `source activate GPU` or `source activate CPU` respectively. (or `conda activate`)

Note: MKL stands for Math Kernel Library, which always uses the most optimized CPU instructions, even if tensorflow throws warnings like
> Your CPU supports instructions that this TensorFlow binary was not compiled to use: SSE4.1 SSE4.2 AVX

## Parallel processing
When processing small jobs, it can be faster to process multiple ones in parallel. 
The provided example `test_parallel.py` trains and evaluates a model for several hyperparameter combinations in parallel.
You can try different values for `nworkers` and check the performance.
