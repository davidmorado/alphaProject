import sys
import numpy      as np
import tensorflow as tf
from os.path import dirname, abspath
from getpass import getuser
from time    import time
start_time = time()

# Print some general information about the job
print(F"The user       is: {getuser()}")
print(F"The virtualenv is: {sys.prefix}")
print(F"The currently running script is: {sys.argv[0]}")
print(F"The script is located in: {abspath(dirname(sys.argv[0]))}")

data = np.load('datasets/mnist.npz')
x_train, x_test = data['x_train']/255.0, data['x_test']/255.0
y_train, y_test = data['y_train'],       data['y_test']

model = tf.keras.models.Sequential([
  tf.keras.layers.Flatten(),
  tf.keras.layers.Dense(512, activation=tf.nn.relu),
  tf.keras.layers.Dropout(0.2),
  tf.keras.layers.Dense(10, activation=tf.nn.softmax)])

model.compile(optimizer= 'adam',
              loss     = 'sparse_categorical_crossentropy',
              metrics  = ['accuracy'])

model.fit(x_train, y_train, epochs=5, verbose=2)
result = model.evaluate(x_test, y_test, verbose=2)

print(F"Final result: {result}")
print(F"Total execution time: {int(time()-start_time)}s")
