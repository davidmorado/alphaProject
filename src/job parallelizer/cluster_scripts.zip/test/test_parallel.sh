#!/usr/bin/env bash
#SBATCH --job-name=test_parallel
#SBATCH --output=test_parallel%j.log
#SBATCH --error=test_parallel%j.err
#SBATCH --partition=TEST
#SBATCH --gres=gpu:1
source activate GPU
srun python test_parallel.py
