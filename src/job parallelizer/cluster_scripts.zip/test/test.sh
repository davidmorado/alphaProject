#!/usr/bin/env bash
#SBATCH --job-name=test
#SBATCH --output=test%j.log
#SBATCH --error=test%j.err
#SBATCH --partition=TEST
#SBATCH --gres=gpu:1
#SBATCH --exclusive=
#SBATCH --mail-user=rscholz@ismll.de
#SBATCH --mail-type=END

source activate GPU
srun python test.py
