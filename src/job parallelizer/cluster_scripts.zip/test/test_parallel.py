import tensorflow as tf
import numpy as np
import os, sys, time, json
from getpass import getuser

def main():
    # general configuration
    config = {'nthreads' : max(int(os.cpu_count()/2),8),
              'nworkers' : 4}

    # save configuration
    with open('config.json', 'w') as write_file:
       json.dump(config, write_file)

    # Hyper-Parameter choices
    HP = {'loss'       : ['sparse_categorical_crossentropy'],
          'neurons'    : [16, 32, 64],
          'optimizer'  : ['SGD', 'adam'],
          'activation' : ['relu', 'tanh']}

    # create a list of all possible hyper-parameter-combinations (=> grid search)
    from itertools import product
    HPC = [dict(zip(HP.keys(), choice)) for choice in product(*HP.values())]
    print(F"The possible Hyperparameter combinations are :{HPC}")

    # create a pool of worker that in parallel tries different HPC
    from multiprocessing import Pool
    start_time = time.time()
    with Pool(config['nworkers'], maxtasksperchild=1) as pool:
        results = pool.map_async(experiment, HPC, chunksize=1).get()
    end_time = time.time()

    print(F"scores are {results}")
    print(F"Total execution time: {int(end_time-start_time)}s")


def experiment(HP):
    # load the configuration
    with open('config.json', 'r') as read_file:
       config = json.load(read_file)

    tfconfig = tf.ConfigProto(
        intra_op_parallelism_threads = config['nthreads'],   # parallelization of single OP
        inter_op_parallelism_threads = config['nthreads'],   # parallelization of disjoint OP
        allow_soft_placement = True,
        gpu_options = tf.GPUOptions(
            allow_growth=True,
            per_process_gpu_memory_fraction=0.9/config['nworkers']))

    sess = tf.Session(config=tfconfig)
    tf.keras.backend.set_session(sess)

    data = np.load('datasets/mnist.npz')
    x_train, x_test = data['x_train']/255.0, data['x_test']/255.0
    y_train, y_test = data['y_train'],       data['y_test']

    model = tf.keras.models.Sequential([
      tf.keras.layers.Flatten(),
      tf.keras.layers.Dense  (HP['neurons'], activation=HP['activation']),
      tf.keras.layers.Dropout(0.2),
      tf.keras.layers.Dense  (10, activation=tf.nn.softmax)])

    model.compile(optimizer = HP['optimizer'],
                  loss      = HP['loss'],
                  metrics   = ['accuracy'])

    model.fit(x_train, y_train, epochs=5, verbose=0)
    result = model.evaluate(x_test, y_test, verbose=0)
    print(F"The HPC: {HP}")
    print(F"Yielded: {result}")
    return result[1]

if __name__ == '__main__':
    main()
